"use client"

import Header from "@/components/header"
import Hero from "@/components/hero"
import Features from "@/components/features"
import Rooms from "@/components/rooms"
import Reviews from "@/components/reviews"
import Footer from "@/components/footer"
import ChatbotWidget from "@/components/chatbot-widget"

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <Header />
      <Hero />
      <Features />
      <Rooms />
      <Reviews />
      <Footer />
      <ChatbotWidget />
    </main>
  )
}

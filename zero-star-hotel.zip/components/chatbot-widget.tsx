"use client"

import { useEffect, useState } from "react"

export default function ChatbotWidget() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    // Load Botpress chatbot script
    const script = document.createElement("script")
    script.src =
      "https://cdn.botpress.cloud/webchat/v3.3/shareable.html?configUrl=https://files.bpcontent.cloud/2025/10/17/03/20251017031525-MENA8NFA.json"
    script.async = true
    script.onload = () => setIsLoaded(true)
    document.body.appendChild(script)

    return () => {
      if (document.body.contains(script)) {
        document.body.removeChild(script)
      }
    }
  }, [])

  return (
    <div
      className="fixed bottom-6 right-6 z-50"
      style={{
        width: "380px",
        height: "500px",
      }}
    >
      {/* Botpress chatbot will be injected here */}
    </div>
  )
}

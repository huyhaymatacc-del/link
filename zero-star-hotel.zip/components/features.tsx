export default function Features() {
  const features = [
    {
      icon: "🛏️",
      title: "Giường cứng như đá",
      description: "Giường của chúng tôi được làm từ vật liệu tự nhiên - cụ thể là đá thực sự",
    },
    {
      icon: "🚿",
      title: 'Vòi sen "tuyệt vời"',
      description: "Nước chảy với áp lực của một chiếc ống nước bị tắc",
    },
    {
      icon: "❄️",
      title: "Điều hòa không khí",
      description: "Một cửa sổ mở được - tự nhiên và miễn phí!",
    },
    {
      icon: "📺",
      title: "TV 4K",
      description: "4 kênh, không phải 4K. Chúng tôi trung thực về quảng cáo",
    },
    {
      icon: "🍽️",
      title: "Bữa sáng miễn phí",
      description: "Một cốc nước lạnh và một gói bánh quy từ năm 2019",
    },
    {
      icon: "🔐",
      title: "An toàn 24/7",
      description: "Chúng tôi có một chó canh - đôi khi nó thức dậy",
    },
  ]

  return (
    <section id="features" className="py-20 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <h3 className="text-4xl font-bold text-center mb-16 text-balance">Các Tiện Nghi "Tuyệt Vời" Của Chúng Tôi</h3>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="p-6 bg-card rounded-lg border border-border hover:shadow-lg transition">
              <div className="text-5xl mb-4">{feature.icon}</div>
              <h4 className="text-xl font-bold mb-2">{feature.title}</h4>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default function Hero() {
  return (
    <section className="relative py-20 px-4 bg-gradient-to-b from-secondary to-background overflow-hidden">
      <div className="max-w-7xl mx-auto text-center">
        <h2 className="text-5xl md:text-6xl font-bold mb-6 text-balance">Chào mừng đến Hotel Zero Stars</h2>
        <p className="text-xl md:text-2xl mb-8 text-muted-foreground max-w-2xl mx-auto">
          Nơi duy nhất mà bạn sẽ nhận được chính xác những gì bạn trả tiền - không hơn, không kém! 🏚️
        </p>
        <div className="flex gap-4 justify-center flex-wrap">
          <button className="bg-accent text-accent-foreground px-8 py-3 rounded-lg font-semibold hover:opacity-90 transition">
            Đặt phòng ngay
          </button>
          <button className="border-2 border-accent text-accent px-8 py-3 rounded-lg font-semibold hover:bg-accent hover:text-accent-foreground transition">
            Xem chi tiết
          </button>
        </div>
      </div>

      {/* Decorative broken elements */}
      <div className="absolute top-10 right-10 text-6xl opacity-20">🪟</div>
      <div className="absolute bottom-10 left-10 text-6xl opacity-20">🔧</div>
    </section>
  )
}

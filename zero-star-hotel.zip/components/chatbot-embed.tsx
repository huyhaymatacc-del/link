"use client"

export default function ChatbotEmbed() {
  return (
    <div className="w-full">
      <iframe
        src="https://cdn.botpress.cloud/webchat/v3.3/shareable.html?configUrl=https://files.bpcontent.cloud/2025/10/17/03/20251017031525-MENA8NFA.json"
        style={{
          width: "100%",
          height: "500px",
          border: "none",
          borderRadius: "8px",
        }}
        title="Hotel Zero Stars Chatbot"
      />
    </div>
  )
}

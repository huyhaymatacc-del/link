import ChatbotEmbed from "./chatbot-embed"

export default function Footer() {
  return (
    <footer id="contact" className="bg-primary text-primary-foreground py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h4 className="font-bold text-lg mb-4">Hotel Zero Stars</h4>
            <p className="text-sm opacity-80">Nơi duy nhất mà bạn biết chính xác những gì bạn sẽ nhận được.</p>
          </div>
          <div>
            <h4 className="font-bold text-lg mb-4">Liên Hệ</h4>
            <p className="text-sm opacity-80">📞 1-800-ZERO-STAR</p>
            <p className="text-sm opacity-80">📧 hello@zerostars.com</p>
            <p className="text-sm opacity-80">📍 123 Đường Rẻ Tiền, Thành Phố</p>
          </div>
          <div>
            <h4 className="font-bold text-lg mb-4">Theo Dõi</h4>
            <div className="flex gap-4">
              <a href="#" className="hover:opacity-80 transition">
                Facebook
              </a>
              <a href="#" className="hover:opacity-80 transition">
                Twitter
              </a>
              <a href="#" className="hover:opacity-80 transition">
                Instagram
              </a>
            </div>
          </div>
        </div>

        <div className="mb-8 border-t border-primary-foreground/20 pt-8">
          <h4 className="font-bold text-lg mb-4">Chat với chúng tôi</h4>
          <ChatbotEmbed />
        </div>

        <div className="border-t border-primary-foreground/20 pt-8 text-center text-sm opacity-80">
          <p>&copy; 2025 Hotel Zero Stars. Tất cả quyền được bảo lưu (nhưng không có gì để bảo lưu).</p>
        </div>
      </div>
    </footer>
  )
}

export default function Rooms() {
  const rooms = [
    {
      name: "Phòng Cơ Bản",
      price: "99.000đ",
      features: ["Giường", "Cửa sổ (có thể)", "Bóng đèn (50% thời gian hoạt động)"],
      image: "🚪",
    },
    {
      name: "Phòng Deluxe",
      price: "199.000đ",
      features: ["Giường + Ghế", "Cửa sổ (chắc chắn)", "Bóng đèn (75% thời gian)"],
      image: "🏠",
    },
    {
      name: "Phòng Suite",
      price: "299.000đ",
      features: ["Giường + Ghế + Bàn", "Cửa sổ + Ban công", "Bóng đèn (90% thời gian)"],
      image: "🏰",
    },
  ]

  return (
    <section id="rooms" className="py-20 px-4 bg-secondary">
      <div className="max-w-7xl mx-auto">
        <h3 className="text-4xl font-bold text-center mb-16 text-balance">Các Loại Phòng</h3>

        <div className="grid md:grid-cols-3 gap-8">
          {rooms.map((room, index) => (
            <div
              key={index}
              className="bg-card rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition border border-border"
            >
              <div className="h-40 bg-gradient-to-b from-muted to-background flex items-center justify-center text-6xl">
                {room.image}
              </div>
              <div className="p-6">
                <h4 className="text-2xl font-bold mb-2">{room.name}</h4>
                <p className="text-3xl font-bold text-accent mb-4">{room.price}</p>
                <ul className="space-y-2 mb-6">
                  {room.features.map((feature, i) => (
                    <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                      <span className="text-accent">✓</span>
                      {feature}
                    </li>
                  ))}
                </ul>
                <button className="w-full bg-accent text-accent-foreground py-2 rounded-lg font-semibold hover:opacity-90 transition">
                  Đặt ngay
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-primary text-primary-foreground shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
            <div className="text-2xl font-bold">⭐</div>
            <h1 className="text-xl font-bold">Hotel Zero Stars</h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex gap-8">
            <a href="#features" className="hover:opacity-80 transition">
              Tiện nghi
            </a>
            <a href="#rooms" className="hover:opacity-80 transition">
              Phòng
            </a>
            <a href="#reviews" className="hover:opacity-80 transition">
              Đánh giá
            </a>
            <a href="#contact" className="hover:opacity-80 transition">
              Liên hệ
            </a>
          </nav>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-4">
            <a href="#features" className="hover:opacity-80 transition">
              Tiện nghi
            </a>
            <a href="#rooms" className="hover:opacity-80 transition">
              Phòng
            </a>
            <a href="#reviews" className="hover:opacity-80 transition">
              Đánh giá
            </a>
            <a href="#contact" className="hover:opacity-80 transition">
              Liên hệ
            </a>
          </nav>
        )}
      </div>
    </header>
  )
}

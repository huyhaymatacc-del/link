export default function Reviews() {
  const reviews = [
    {
      name: "Nguyễn Văn A",
      rating: "⭐",
      text: "Chính xác như mô tả - tồi tệ! Tôi yêu nó.",
    },
    {
      name: "Trần Thị B",
      rating: "⭐",
      text: "Giường cứng như đá. Chắc chắn là đá. Nhưng giá rẻ!",
    },
    {
      name: "Phạm Văn C",
      rating: "⭐",
      text: "Vòi sen chảy như một ống nước bị tắc. Hoàn hảo cho trải nghiệm thực tế.",
    },
    {
      name: "Lê Thị D",
      rating: "⭐",
      text: "Không có gì để nói ngoài việc nó là một khách sạn 0 sao thực sự!",
    },
  ]

  return (
    <section id="reviews" className="py-20 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <h3 className="text-4xl font-bold text-center mb-16 text-balance">Đánh Giá Từ Khách Hàng</h3>

        <div className="grid md:grid-cols-2 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="p-6 bg-card rounded-lg border border-border">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-bold text-lg">{review.name}</h4>
                <span className="text-2xl">{review.rating}</span>
              </div>
              <p className="text-muted-foreground italic">"{review.text}"</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
